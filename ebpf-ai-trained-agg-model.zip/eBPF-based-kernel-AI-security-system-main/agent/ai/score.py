#!/usr/bin/env python3
"""Offline decision preview; does not modify firewall or kill processes."""
import argparse
import json
import re
from pathlib import Path

import joblib
from train import windows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('traces', type=Path)
    parser.add_argument('--model', required=True, type=Path)
    parser.add_argument('--output', type=Path, default=Path('decisions.jsonl'))
    args = parser.parse_args()
    meta = json.loads((args.model / 'meta.json').read_text())
    vectors, _ = windows(args.traces, meta['vocab_size'])
    paths = sorted(args.traces.glob('*.txt'), key=lambda p: (int(m.group(2)), int(m.group(1)), int(m.group(3))) if (m := re.match(r'^.+-(\d+)-(\d+)-(\d+)\.txt$', p.name)) else (0, 0, p.name))
    model = joblib.load(args.model / 'model.pkl')  # Load only trusted model bundles.
    scores = -model.score_samples(vectors)
    streaks = {}
    with args.output.open('w') as output:
        for path, score in zip(paths, scores):
            match = re.match(r'^.+-(\d+)-(\d+)-(\d+)\.txt$', path.name)
            key = (match.group(1), match.group(2)) if match else path.name
            streaks[key] = streaks.get(key, 0) + 1 if score >= meta['block_threshold'] else 0
            decision = ('block_candidate' if streaks[key] >= 2 else
                        'alert' if score >= meta['alert_threshold'] else 'allow')
            output.write(json.dumps({'window': path.name, 'score': float(score), 'decision': decision}) + '\n')
    print(f'wrote {len(paths)} decisions to {args.output}; block_candidate requires review before enforcement')


if __name__ == '__main__':
    main()
