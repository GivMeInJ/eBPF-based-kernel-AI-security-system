#!/usr/bin/env python3
"""Train a labeled classifier on the 31-feature agg_1s.npz format."""
import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import sklearn
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score


def load_dataset(path):
    with np.load(path, allow_pickle=False) as data:
        required = {'X', 'labels', 'names', 'sessions'}
        if not required.issubset(data.files):
            raise ValueError(f'missing arrays: {sorted(required - set(data.files))}')
        X = data['X'].copy()
        labels = data['labels'].copy()
        names = data['names'].copy()
        sessions = data['sessions'].copy()
    if X.ndim != 2 or X.shape[1] != len(names) or len(X) != len(labels) or len(X) != len(sessions):
        raise ValueError('inconsistent feature and label shapes')
    if not np.isfinite(X).all() or set(np.unique(labels)) != {'normal', 'attack'}:
        raise ValueError('expected finite features and normal/attack labels')
    return X, (labels == 'attack'), names, sessions


def threshold_for_fpr(normal_scores, target):
    ordered = np.sort(normal_scores)
    index = min(len(ordered) - 1, max(0, int(np.ceil((1 - target) * len(ordered))) - 1))
    return float(ordered[index])


def metrics(scores, truth, threshold):
    predicted = scores > threshold
    normal = ~truth
    return {'normal_windows': int(normal.sum()),
            'false_alarms': int((predicted & normal).sum()),
            'false_positive_rate': float((predicted & normal).sum() / normal.sum()),
            'attack_windows': int(truth.sum()),
            'detected_attack_windows': int((predicted & truth).sum()),
            'attack_detection_rate': float((predicted & truth).sum() / truth.sum())}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('dataset', type=Path)
    parser.add_argument('--output', type=Path, default=Path('model_agg'))
    parser.add_argument('--alert-fpr', type=float, default=0.01)
    parser.add_argument('--block-fpr', type=float, default=0.005)
    args = parser.parse_args()
    if not 0 < args.block_fpr < args.alert_fpr < 1:
        parser.error('require 0 < block-fpr < alert-fpr < 1')
    X, y, names, sessions = load_dataset(args.dataset)
    train = np.isin(sessions, [f's{i}' for i in range(1, 8)])
    calibration = np.isin(sessions, ['s8', 's9'])
    test = np.isin(sessions, ['s10', 's11'])
    if not (train | calibration | test).all() or not all(np.any(mask & y) and np.any(mask & ~y)
            for mask in (train, calibration, test)):
        parser.error('expected labeled sessions s1 through s11 with both classes')

    model = RandomForestClassifier(n_estimators=300, min_samples_leaf=3,
                                   class_weight='balanced', random_state=42, n_jobs=-1)
    model.fit(X[train], y[train])
    cal_scores = model.predict_proba(X[calibration])[:, 1]
    normal_scores = cal_scores[~y[calibration]]
    alert = threshold_for_fpr(normal_scores, args.alert_fpr)
    block = threshold_for_fpr(normal_scores, args.block_fpr)
    test_scores = model.predict_proba(X[test])[:, 1]
    report = {
        'split': {'train': 's1-s7', 'calibration': 's8-s9', 'test': 's10-s11',
                  'train_windows': int(train.sum()), 'calibration_windows': int(calibration.sum()),
                  'test_windows': int(test.sum())},
        'calibration_normal_windows': int((~y[calibration]).sum()),
        'alert': {'threshold': alert, 'target_calibration_fpr': args.alert_fpr,
                  **metrics(test_scores, y[test], alert)},
        'block_candidate': {'threshold': block, 'target_calibration_fpr': args.block_fpr,
                             **metrics(test_scores, y[test], block)},
        'test_roc_auc': float(roc_auc_score(y[test], test_scores)),
        'unit': 'one labeled 1-second feature row; not a user or attack attempt'
    }
    args.output.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, args.output / 'model.pkl')
    (args.output / 'meta.json').write_text(json.dumps({
        'model': 'RandomForestClassifier', 'sklearn_version': sklearn.__version__,
        'feature_names': names.tolist(), 'alert_threshold': alert,
        'block_candidate_threshold': block, 'comparison': 'score > threshold',
        'score_meaning': 'estimated attack class probability, not a calibrated probability',
        'enforcement': 'offline scoring only; no blocking'}, indent=2) + '\n')
    (args.output / 'evaluation.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
