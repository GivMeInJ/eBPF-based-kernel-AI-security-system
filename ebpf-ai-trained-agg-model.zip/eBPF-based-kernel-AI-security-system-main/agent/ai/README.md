# AI training pipeline

The collector's binary syscall stream becomes a normal-only IsolationForest
model. Collect normal workload data on the Linux machine that will run
detection later.

Install the dependencies and build the map once:

```bash
pip3 install -r ai/requirements.txt
sudo apt-get install -y auditd
python3 ai/syscall_map.py /path/to/OSCAIR_Syscall_Map.txt --output syscall_map_x86_64.json
```

Collect only a dedicated cgroup. The model uses syscall entry IDs only.

```bash
CGID=$(stat -c %i /sys/fs/cgroup/trainset)
sudo .output/host-events --syscalls-enter-only --no-file --network-events none \
  --target-cgroup "$CGID" --queue-capacity 65536 --ringbuf-bytes 67108864 \
  --format binary --output normal.bin
```

Convert only captures whose final collector statistics report zero queue and
ring-buffer drops. The converter also rejects a lossy capture.

```bash
python3 ai/bin2traces.py normal.bin traces --map syscall_map_x86_64.json
python3 ai/train.py traces --map syscall_map_x86_64.json --output model
```

Keep `model.pkl`, `syscall_map_x86_64.json`, and `meta.json` together when
deploying. Raw production captures are ignored by Git because they may disclose
workload information. Commit the generated model bundle when it is appropriate
to share it with the team.

## Evaluation and alert policy

Capture **separate** normal service traffic for training, later normal operation
for a false positive test, and labeled attacks against that same service for a
true positive test. Keep the same syscall map and converter window settings for
all captures; use separate output directories. Include login, uploads, scheduled
jobs, restarts, and peak traffic in the normal captures. Record attack scenario,
attempt count, and whether each attempt succeeded; test multiple attack types
and intensities, including unseen variants. Do not train on test captures.

```bash
python3 ai/train.py train-normal --map syscall_map_x86_64.json --output model \
  --test-normal later-normal --test-attack labeled-attacks
python3 ai/score.py later-normal --model model --output decisions.jsonl
```

`evaluation.json` reports counts and fractions for independent normal and attack
windows. Normal alert rate is a window-level FPR and attack alert rate is a
window-level detection rate; report per-attempt recall separately after mapping
windows to attack attempts. Calibrated FPR is **not** an independent test result.
A target such as 99% detection and under 1% false positives is unverified until
held-out data meets it, with denominators and confidence intervals reported.
The old `--fpr` controls the alert threshold; `--block-fpr` controls a stricter
block threshold. A score of `0.8` has no universal meaning for IsolationForest:
choose thresholds from normal scores and check detection against labeled attacks.
`score.py` only previews decisions: it alerts on one elevated window, and marks
a block candidate after two consecutive high-score windows for a process.
No automatic blocking is wired to the collector. Integrate enforcement only
after independent validation and a clear rollback path.

Current features are normalized syscall counts, so order, arguments, return
values, and network destinations are invisible to the model. A dedicated service
with repeatable normal workloads is a suitable pilot; retrain/calibrate per
service and compare against this baseline before adding sequence or network
features. Treat unusual behavior as a signal requiring context, not proof that
a particular user is an attacker.

## Labeled 1-second aggregate dataset (`agg_1s.npz`)

This is a **different input format** from the syscall-ID `.txt` windows above.
Use `train_agg.py` for arrays `X`, `labels`, `names`, and `sessions` in this NPZ.
The classifier uses the provided normal/attack labels, 31 features, and
session-separated training, calibration, and test sets. It reads stored data
only; it cannot execute any attack or block traffic.

```bash
python3 ai/train_agg.py agg_1s.npz --output model_agg
python3 ai/score_agg.py agg_1s.npz --model model_agg --output decisions.jsonl
```

Keep `model_agg/model.pkl`, `meta.json`, and `evaluation.json` together. The
reported FPR and detection rate are **per 1-second row**, not per user, session,
or attack attempt. The threshold is learned only from calibration normal rows.
Even a strong result on held-out sessions cannot establish performance on a new
service or unknown attack techniques. Do not enable automatic blocking from
these results; inspect false alerts and test separate real-world data first.
