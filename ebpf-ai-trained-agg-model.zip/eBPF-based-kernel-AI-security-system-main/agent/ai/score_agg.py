#!/usr/bin/env python3
"""Score stored 31-feature NPZ rows; this never executes attack code or blocks."""
import argparse
import json
from pathlib import Path

import joblib
import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('dataset', type=Path)
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=Path('agg_decisions.jsonl'))
    args = parser.parse_args()
    meta = json.loads((args.model / 'meta.json').read_text())
    with np.load(args.dataset, allow_pickle=False) as data:
        X = data['X']
        names = data['names']
        if names.tolist() != meta['feature_names'] or not np.isfinite(X).all():
            raise ValueError('feature names/order mismatch or non-finite data')
        model = joblib.load(args.model / 'model.pkl')  # Only load trusted bundles.
        scores = model.predict_proba(X)[:, 1]
    with args.output.open('w') as stream:
        for i, score in enumerate(scores):
            decision = ('block_candidate' if score > meta['block_candidate_threshold'] else
                        'alert' if score > meta['alert_threshold'] else 'allow')
            stream.write(json.dumps({'row': i, 'score': float(score), 'decision': decision}) + '\n')
    print(f'wrote {len(scores)} offline decisions to {args.output}')


if __name__ == '__main__':
    main()
