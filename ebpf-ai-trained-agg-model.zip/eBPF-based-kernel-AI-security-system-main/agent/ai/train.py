#!/usr/bin/env python3
"""Train on normal syscall windows; calibrate on later normal windows and evaluate separately."""
import argparse
import json
import re
from pathlib import Path

import joblib
import numpy as np
import sklearn
from sklearn.ensemble import IsolationForest


def windows(folder, vocab_size):
    paths = sorted(folder.glob('*.txt'), key=lambda p: (int(m.group(2)), int(m.group(1)), int(m.group(3))) if (m := re.match(r'^.+-(\d+)-(\d+)-(\d+)\.txt$', p.name)) else (0, 0, p.name))
    if not paths:
        raise ValueError(f'no .txt windows in {folder}')
    rows, groups = [], []
    for path in paths:
        raw = path.read_text().strip()
        if not raw:
            raise ValueError(f'empty window: {path}')
        try:
            values = np.asarray([int(x) for x in raw.split()], dtype=np.int64)
        except ValueError as exc:
            raise ValueError(f'non-integer syscall ID: {path}') from exc
        if np.any((values < 0) | (values >= vocab_size)):
            raise ValueError(f'syscall ID outside map: {path}')
        row = np.bincount(values, minlength=vocab_size).astype(np.float32)
        rows.append(row / len(values))
        # Converter names: normal-COMM-TGID-TIMESTAMP-WINDOW.txt.
        match = re.match(r'^.+-(\d+)-(\d+)-(\d+)\.txt$', path.name)
        groups.append((int(match.group(2)), int(match.group(1))) if match else (0, path.name))
    return np.stack(rows), groups


def counts(scores, threshold):
    return int(np.count_nonzero(scores >= threshold)), len(scores)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('traces', type=Path, help='normal windows from a dedicated service')
    parser.add_argument('--map', required=True, type=Path)
    parser.add_argument('--output', default=Path('model'), type=Path)
    parser.add_argument('--fpr', type=float, default=0.005, help='calibration alert fraction')
    parser.add_argument('--block-fpr', type=float, default=0.001, help='calibration block fraction')
    parser.add_argument('--test-normal', type=Path, help='later normal capture, independent of training')
    parser.add_argument('--test-attack', type=Path, help='labeled attack windows, independent of training')
    args = parser.parse_args()
    if not 0 < args.block_fpr < args.fpr < 1:
        parser.error('require 0 < block-fpr < fpr < 1')
    mapping = json.loads(args.map.read_text())
    vocab_size = int(mapping['vocab_size'])
    if vocab_size <= 0:
        parser.error('vocab_size must be positive')
    matrix, groups = windows(args.traces, vocab_size)
    if len(matrix) < 200:
        parser.error('need at least 200 normal windows')
    # Keep all windows of a process instance on one side of the split.
    unique_groups = list(dict.fromkeys(groups))
    if len(unique_groups) < 5:
        parser.error('need at least five distinct normal process instances')
    split = max(1, int(len(unique_groups) * 0.8))
    train_groups = set(unique_groups[:split])
    train = matrix[[g in train_groups for g in groups]]
    calibration = matrix[[g not in train_groups for g in groups]]
    if not len(calibration):
        parser.error('calibration set is empty')
    model = IsolationForest(n_estimators=300, random_state=42, n_jobs=-1).fit(train)
    calibration_scores = -model.score_samples(calibration)
    alert = float(np.quantile(calibration_scores, 1 - args.fpr))
    block = float(np.quantile(calibration_scores, 1 - args.block_fpr))
    report = {'calibration': {'train_windows': len(train), 'calibration_windows': len(calibration),
              'train_processes': len(train_groups), 'calibration_processes': len(unique_groups) - split,
              'observed_alert_fraction': counts(calibration_scores, alert)[0] / len(calibration),
              'observed_block_fraction': counts(calibration_scores, block)[0] / len(calibration)}}
    for label, folder in [('normal', args.test_normal), ('attack', args.test_attack)]:
        if folder is None:
            continue
        features, _ = windows(folder, vocab_size)
        scores = -model.score_samples(features)
        report[label] = {'windows': len(scores), 'alerted': counts(scores, alert)[0],
                         'block_candidates': counts(scores, block)[0],
                         'alert_rate': counts(scores, alert)[0] / len(scores),
                         'block_candidate_rate': counts(scores, block)[0] / len(scores)}
    args.output.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, args.output / 'model.pkl')
    (args.output / 'syscall_map_x86_64.json').write_text(json.dumps(mapping, indent=2) + '\n')
    (args.output / 'meta.json').write_text(json.dumps({'model': 'IsolationForest',
        'sklearn_version': sklearn.__version__, 'vocab_size': vocab_size, 'window': 500,
        'alert_threshold': alert, 'block_threshold': block,
        'requested_alert_fpr': args.fpr, 'requested_block_fpr': args.block_fpr,
        'policy': 'alert at alert_threshold; block only after two consecutive block candidates from same process'}, indent=2) + '\n')
    (args.output / 'evaluation.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
