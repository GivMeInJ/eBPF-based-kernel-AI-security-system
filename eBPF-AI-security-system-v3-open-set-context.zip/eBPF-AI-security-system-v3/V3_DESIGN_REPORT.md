
# V3 모델 개선 설계 보고서

## 목표
기존 syscall histogram 중심 탐지를 실제 eBPF 운용 구조에 맞게 확장한다.

## 해결하려는 문제
- 단일 syscall 기반 오탐
- 프로세스/서비스 맥락 부족
- 미학습 공격을 정상으로 확정하는 문제
- 임의 threshold에 의존하는 문제
- AI가 즉시 차단을 결정하는 위험

## 핵심 개선
1. 프로세스 인스턴스 + 시간 Window 단위 판단
2. Syscall frequency + bigram + 행동 통계
3. Process/File/Network context 추가
4. Random Forest = 알려진 공격 분류
5. Isolation Forest = 정상에서 벗어난 신규 행위 탐지
6. 정상 holdout으로 novelty threshold를 FPR 기준으로 보정
7. known attack + normal calibration으로 RF threshold 선택
8. NORMAL / SUSPICIOUS / ALERT의 abstention 구조
9. ALERT도 자동 차단하지 않고 정책 계층으로 분리
10. unseen attack을 별도 데이터셋으로 평가

## 중요한 한계
V3 코드를 만드는 것만으로 문제를 '완전히 해결'했다고 주장할 수 없다.
실제 해결 여부는 다음 실험으로 증명해야 한다.

- 정상 사용자 FPR
- known attack recall
- unseen attack suspicious/alert rate
- 서비스별 FPR
- 공격 유형별 recall
- 1~5초 window 지연시간
- eBPF event drop rate

특히 unseen attack 데이터는 threshold를 고르는 데 사용하면 안 된다.
