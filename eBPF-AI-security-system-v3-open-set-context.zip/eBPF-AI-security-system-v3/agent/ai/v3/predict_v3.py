
#!/usr/bin/env python3
import argparse,json
from pathlib import Path
import joblib,numpy as np
from features import featurize_windows
from ndjson_windows import read_events,make_windows

ap=argparse.ArgumentParser()
ap.add_argument("capture",type=Path)
ap.add_argument("--model",default="model_v3")
args=ap.parse_args()

m=json.loads((Path(args.model)/"metadata.json").read_text())
rf=joblib.load(Path(args.model)/"rf_v3.joblib")
iso=joblib.load(Path(args.model)/"isolation_v3.joblib")
events=read_events(args.capture)
windows,meta=make_windows(events,events_per_window=m["window_events"])
X=featurize_windows(windows)
rp=rf.predict_proba(X)[:,1]
nv=-iso.score_samples(X)
for i,(r,n,md) in enumerate(zip(rp,nv,meta)):
    if r>=m["rf_threshold"] and n>=m["novelty_threshold"]:
        status="ALERT"
    elif r>=m["rf_threshold"] or n>=m["novelty_threshold"]:
        status="SUSPICIOUS"
    else:
        status="NORMAL"
    print(f"{i:04d} tgid={md['tgid']} rf={r:.4f} novelty={n:.4f} {status}")
