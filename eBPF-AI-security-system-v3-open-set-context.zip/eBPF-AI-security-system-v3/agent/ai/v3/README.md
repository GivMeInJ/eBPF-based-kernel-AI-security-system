
# V3 — Open-set + Context-aware eBPF detector

## What changed

V3 is designed around the four project concerns:

1. **Where to detect:** eBPF collects kernel events; AI decides on a
   process-instance/time-window, not a single syscall.
2. **User vs attacker:** the model scores behavior, not a human identity.
   PID/TGID/PPID/task lifetime, process execs, file operations, and network
   events are included as context.
3. **False positives:** thresholds are calibrated on held-out normal data.
   A two-signal policy requires both RF and novelty signals for ALERT.
4. **Unseen attacks:** IsolationForest is trained only on normal behavior and
   the policy has an explicit SUSPICIOUS abstention state. Unseen attacks are
   evaluated separately and are never used to tune the thresholds.

## Decision policy

NORMAL:
- RF score below calibrated threshold AND
- novelty score below normal-calibrated threshold.

SUSPICIOUS:
- only one of the two signals is high.

ALERT:
- both signals are high.

BLOCK:
- intentionally NOT automatic. A separate policy engine should decide whether
  a high-confidence alert is safe to block after service-specific validation.

This is important: no ML model can guarantee that every unseen attack will be
detected or that false positives are zero. V3 is an engineering design that
makes those trade-offs measurable and safer.

## Data

The original collector already emits:
- syscall events
- process fork/exec/exit
- file open/unlink
- network events
- PID/TGID/PPID/UID/GID/cgroup/task start time
- collector health/drop counters

Use the collector's NDJSON output. Put labeled captures in:

data/
  normal/*.jsonl
  known_attack/*.jsonl
  unseen_attack/*.jsonl

Known attacks are used for supervised RF training/calibration.
Normal data is used for the novelty model and FPR calibration.
Unseen attacks are NEVER used in training or threshold selection.

## Train

cd agent/ai/v3
python3 train_v3.py \
  --normal ../../../data/normal \
  --attack ../../../data/known_attack \
  --output ../../../model_v3 \
  --target-fpr 0.01

## Evaluate unseen attacks

python3 evaluate_unseen.py \
  --normal ../../../data/normal \
  --unseen-attack ../../../data/unseen_attack \
  --model ../../../model_v3

## Inference

python3 predict_v3.py /path/to/live-capture.jsonl --model ../../../model_v3
