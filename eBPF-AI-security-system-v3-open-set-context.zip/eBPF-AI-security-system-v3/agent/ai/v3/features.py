
import math
from collections import Counter, defaultdict
import numpy as np

SYSCALL_VOCAB = 1088
BIGRAM_VOCAB = 256

def _safe_ratio(a, b):
    return float(a) / float(b) if b else 0.0

def _entropy(values):
    if not values:
        return 0.0
    c = Counter(values)
    n = len(values)
    return float(-sum((v/n) * math.log2(v/n) for v in c.values()))

def _hash_bigram(a, b, size=BIGRAM_VOCAB):
    return ((int(a) * 1315423911) ^ (int(b) * 2654435761)) % size

def window_features(events, vocab=SYSCALL_VOCAB, bigram_vocab=BIGRAM_VOCAB):
    """Build one feature vector from one process/time window.

    Expected event dicts are the collector's NDJSON records.  The feature set
    deliberately combines syscall behavior with process/file/network context.
    """
    syscalls = [int(e["syscall_id"]) for e in events
                if e.get("event_type") == "SYSCALL_ENTER"
                and 0 <= int(e.get("syscall_id", -1)) < vocab]

    hist = np.bincount(syscalls, minlength=vocab).astype(np.float32)
    if hist.sum():
        hist /= hist.sum()

    bigram = np.zeros(bigram_vocab, dtype=np.float32)
    for a, b in zip(syscalls[:-1], syscalls[1:]):
        bigram[_hash_bigram(a, b, bigram_vocab)] += 1
    if bigram.sum():
        bigram /= bigram.sum()

    files = [e for e in events if e.get("event_type") in ("FILE_OPEN", "FILE_UNLINK")]
    nets = [e for e in events if e.get("event_type") in (
        "NETWORK_CONNECT", "NETWORK_BIND", "NETWORK_LISTEN",
        "NETWORK_ACCEPT", "NETWORK_UDP_SEND", "NETWORK_TCP_STATE"
    )]
    execs = [e for e in events if e.get("event_type") == "PROCESS_EXEC"]
    forks = [e for e in events if e.get("event_type") == "PROCESS_FORK"]

    sensitive = 0
    external_net = 0
    privileged = 0
    for e in files:
        p = str(e.get("path") or "")
        if p.startswith(("/etc/", "/root/", "/boot/", "/proc/", "/sys/")):
            sensitive += 1

    for e in nets:
        ip = e.get("dst_ip")
        if ip and ip not in ("127.0.0.1", "::1"):
            external_net += 1

    uids = [int(e.get("uid", 0)) for e in events]
    if uids and min(uids) == 0:
        privileged = 1

    unique_syscalls = len(set(syscalls))
    n = len(syscalls)
    repeat_adj = sum(a == b for a, b in zip(syscalls[:-1], syscalls[1:]))
    max_freq = float(hist.max()) if hist.size else 0.0

    context = np.array([
        math.log1p(len(events)),
        math.log1p(n),
        _safe_ratio(unique_syscalls, n),
        _safe_ratio(repeat_adj, max(n - 1, 1)),
        max_freq,
        _entropy(syscalls),
        math.log1p(len(files)),
        math.log1p(sensitive),
        math.log1p(len(nets)),
        math.log1p(external_net),
        math.log1p(len(execs)),
        math.log1p(len(forks)),
        privileged,
        _safe_ratio(sensitive, len(files)),
        _safe_ratio(external_net, len(nets)),
    ], dtype=np.float32)

    return np.concatenate([hist, bigram, context]).astype(np.float32)

def featurize_windows(windows, vocab=SYSCALL_VOCAB, bigram_vocab=BIGRAM_VOCAB):
    return np.vstack([window_features(w, vocab, bigram_vocab) for w in windows])
