
import json
from collections import defaultdict
from pathlib import Path

EVENTS_PER_WINDOW = 150
WINDOW_NS = 5_000_000_000

def read_events(path):
    events = []
    with Path(path).open(encoding="utf-8") as f:
        for line in f:
            line=line.strip()
            if not line:
                continue
            events.append(json.loads(line))
    return events

def make_windows(events, events_per_window=EVENTS_PER_WINDOW, window_ns=WINDOW_NS):
    """Group events by process instance (tgid + task_start_ns).

    A new window starts when either the event count or wall-clock span reaches
    the configured limit. This avoids making a decision from one syscall.
    """
    by_proc = defaultdict(list)
    for e in events:
        if e.get("event_type") == "HEALTH":
            continue
        key = (int(e.get("tgid", 0)), int(e.get("task_start_ns", 0)))
        by_proc[key].append(e)

    windows=[]
    meta=[]
    for key, evs in by_proc.items():
        evs.sort(key=lambda x: int(x.get("timestamp_ns", 0)))
        cur=[]
        start=None
        for e in evs:
            ts=int(e.get("timestamp_ns",0))
            if start is None:
                start=ts
            if cur and (len(cur)>=events_per_window or ts-start>=window_ns):
                windows.append(cur)
                meta.append({"tgid":key[0], "task_start_ns":key[1],
                             "start_ns":int(cur[0].get("timestamp_ns",0)),
                             "end_ns":int(cur[-1].get("timestamp_ns",0))})
                cur=[]
                start=ts
            cur.append(e)
        if cur:
            windows.append(cur)
            meta.append({"tgid":key[0], "task_start_ns":key[1],
                         "start_ns":int(cur[0].get("timestamp_ns",0)),
                         "end_ns":int(cur[-1].get("timestamp_ns",0))})
    return windows, meta
