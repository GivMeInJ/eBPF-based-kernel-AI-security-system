
#!/usr/bin/env python3
import argparse, json, time
from pathlib import Path
import joblib
import numpy as np
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, f1_score
from sklearn.model_selection import train_test_split

from features import featurize_windows
from ndjson_windows import read_events, make_windows

def load_dir(directory):
    windows=[]
    for p in sorted(Path(directory).glob("*.jsonl")):
        ev=read_events(p)
        ws,_=make_windows(ev)
        windows.extend(ws)
    return windows

def metrics(y,p):
    tn,fp,fn,tp=confusion_matrix(y,p,labels=[0,1]).ravel()
    return {
        "accuracy":float(accuracy_score(y,p)),
        "precision":float(precision_score(y,p,zero_division=0)),
        "recall":float(recall_score(y,p,zero_division=0)),
        "f1":float(f1_score(y,p,zero_division=0)),
        "fpr":float(fp/max(tn+fp,1)),
        "tn":int(tn),"fp":int(fp),"fn":int(fn),"tp":int(tp)
    }

def choose_rf_threshold(prob, y, target_fpr):
    candidates=np.unique(np.r_[np.linspace(0.05,0.99,95), prob])
    best=None
    for t in candidates:
        p=(prob>=t).astype(int)
        m=metrics(y,p)
        if m["fpr"] <= target_fpr:
            key=(m["recall"],m["f1"],-m["fpr"])
            if best is None or key > best[0]:
                best=(key,float(t),m)
    if best is None:
        # Conservative fallback: smallest threshold satisfying the lowest
        # observed FPR. It is still reported and must be validated again.
        vals=[]
        for t in candidates:
            m=metrics(y,(prob>=t).astype(int))
            vals.append((m["fpr"],-m["recall"],float(t),m))
        vals.sort()
        _,_,t,m=vals[0]
        return t,m
    return best[1],best[2]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--normal",required=True,help="directory of normal JSONL captures")
    ap.add_argument("--attack",required=True,help="directory of known-attack JSONL captures")
    ap.add_argument("--output",default="model_v3")
    ap.add_argument("--target-fpr",type=float,default=0.01)
    ap.add_argument("--events-per-window",type=int,default=150)
    args=ap.parse_args()

    normal=load_dir(args.normal)
    attack=load_dir(args.attack)
    if len(normal)<100 or len(attack)<20:
        raise SystemExit("Need substantially more normal/attack windows before training.")

    # Split before fitting. Normal data also gets a holdout.
    ntr,ncal=train_test_split(np.arange(len(normal)),test_size=.25,random_state=42)
    atr,acal=train_test_split(np.arange(len(attack)),test_size=.25,random_state=42)

    train_windows=[normal[i] for i in ntr]+[attack[i] for i in atr]
    cal_windows=[normal[i] for i in ncal]+[attack[i] for i in acal]
    y_cal=np.r_[np.zeros(len(ncal),dtype=int),np.ones(len(acal),dtype=int)]

    Xtr=featurize_windows(train_windows)
    Xcal=featurize_windows(cal_windows)

    t=time.perf_counter()
    rf=RandomForestClassifier(
        n_estimators=400, random_state=42, class_weight="balanced",
        n_jobs=-1, min_samples_leaf=2, max_features="sqrt"
    ).fit(Xtr,np.r_[np.zeros(len(ntr),dtype=int),np.ones(len(atr),dtype=int)])
    rf_train_time=time.perf_counter()-t

    # Novelty detector learns ONLY normal training behavior.
    iso=IsolationForest(n_estimators=400,contamination="auto",random_state=42,n_jobs=-1).fit(
        featurize_windows([normal[i] for i in ntr])
    )

    rf_prob=rf.predict_proba(Xcal)[:,1]
    novelty=-iso.score_samples(Xcal)

    # Novelty threshold is explicitly calibrated from held-out NORMAL data.
    normal_cal_X=featurize_windows([normal[i] for i in ncal])
    normal_novelty=-iso.score_samples(normal_cal_X)
    novelty_threshold=float(np.quantile(normal_novelty,1-args.target_fpr))

    rf_threshold,rf_m=choose_rf_threshold(rf_prob,y_cal,args.target_fpr)

    # Conservative open-set policy:
    # NORMAL only when RF is below its calibrated boundary AND novelty is normal.
    # SUSPICIOUS/ALERT are abstention states, not automatic blocks.
    pred=np.where((rf_prob>=rf_threshold) & (novelty>=novelty_threshold),2,
         np.where((rf_prob>=rf_threshold) | (novelty>=novelty_threshold),1,0))
    # For binary reporting, ALERT is attack; SUSPICIOUS is not counted as attack.
    binary=(pred==2).astype(int)
    binary_metrics=metrics(y_cal,binary)

    out=Path(args.output); out.mkdir(parents=True,exist_ok=True)
    joblib.dump(rf,out/"rf_v3.joblib")
    joblib.dump(iso,out/"isolation_v3.joblib")
    meta={
        "version":"V3-open-set-context",
        "feature_dimension":1088+256+15,
        "window_events":args.events_per_window,
        "target_fpr":args.target_fpr,
        "rf_threshold":rf_threshold,
        "novelty_threshold":novelty_threshold,
        "policy":"NORMAL if both scores below thresholds; SUSPICIOUS if either is high; ALERT only if both are high; no automatic blocking.",
        "training_windows":{"normal":len(ntr),"attack":len(atr)},
        "calibration_windows":{"normal":len(ncal),"attack":len(acal)},
        "calibration_binary_alert_metrics":binary_metrics,
        "rf_calibration_metrics":rf_m,
        "rf_training_time_sec":rf_train_time
    }
    (out/"metadata.json").write_text(json.dumps(meta,indent=2),encoding="utf-8")
    print(json.dumps(meta,indent=2))
    print("\nIMPORTANT: these are calibration results, not unseen-attack results.")
    print("Evaluate unseen attacks in a completely held-out attack directory before deployment.")

if __name__=="__main__":
    main()
