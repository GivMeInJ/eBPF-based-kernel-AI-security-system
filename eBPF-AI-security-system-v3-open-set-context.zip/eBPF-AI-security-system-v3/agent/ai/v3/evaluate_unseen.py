
#!/usr/bin/env python3
"""Evaluate attacks that were NOT used during training/calibration."""
import argparse,json
from pathlib import Path
import joblib,numpy as np
from features import featurize_windows
from ndjson_windows import read_events,make_windows

ap=argparse.ArgumentParser()
ap.add_argument("--normal",required=True)
ap.add_argument("--unseen-attack",required=True)
ap.add_argument("--model",default="model_v3")
args=ap.parse_args()

m=json.loads((Path(args.model)/"metadata.json").read_text())
rf=joblib.load(Path(args.model)/"rf_v3.joblib")
iso=joblib.load(Path(args.model)/"isolation_v3.joblib")

def load(d):
    ws=[]
    for p in sorted(Path(d).glob("*.jsonl")):
        w,_=make_windows(read_events(p),events_per_window=m["window_events"])
        ws.extend(w)
    return ws

normal=load(args.normal); unseen=load(args.unseen_attack)
Xn=featurize_windows(normal); Xu=featurize_windows(unseen)
rn=rf.predict_proba(Xn)[:,1]; ru=rf.predict_proba(Xu)[:,1]
nn=-iso.score_samples(Xn); nu=-iso.score_samples(Xu)

def alert(r,n):
    return (r>=m["rf_threshold"]) & (n>=m["novelty_threshold"])

normal_alert=alert(rn,nn).mean() if len(rn) else 0
unseen_alert=alert(ru,nu).mean() if len(ru) else 0
unseen_susp=((ru>=m["rf_threshold"]) | (nu>=m["novelty_threshold"])).mean() if len(ru) else 0

print(f"Normal ALERT FPR: {normal_alert:.4%}")
print(f"Unseen attack ALERT rate: {unseen_alert:.4%}")
print(f"Unseen attack SUSPICIOUS-or-ALERT rate: {unseen_susp:.4%}")
print("These numbers are the required open-set validation results.")
